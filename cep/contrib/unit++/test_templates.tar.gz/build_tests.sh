#!/bin/bash

# This is a hack that will build all the tests in a given directory
# for this to work, you must be able to locate the libcppunit.

ALLTESTS=alltests.cpp
TEST_PREFIX=cep_test

# look for alltests
if [ ! -f $ALLTESTS ]; then
	echo "$ALLTESTS was not located."
	echo 'Please change $ALLTESTS to point to it or jst bloody make one :)'
	exit 1
fi

#look for test cases
TEST_FILES=`ls $TEST_PREFIX*`
if [ $? -ne 0 ]; then
	echo "There are no tests defined. Remember that test names"
	echo "must bear the prefix 'cep_test' and that it is case sensitive"
	exit 1
fi

for FILE in `ls $TEST_PREFIX*.cpp`; do
	OBJ_NAME=`echo $FILE| sed 's/.cpp//g'`
	echo "g++ -c -o $OBJ_NAME.o $FILE"
	g++ -c -o $OBJ_NAME.o $FILE
done

#make compile the main and link the objects
echo "g++ -o test $ALLTESTS $TEST_PREFIX*.o -lcppunit"
g++ -o test $ALLTESTS $TEST_PREFIX*.o -lcppunit

if [ $? -ne 0 ]; then
	echo build failed!
else
	echo success!
fi
